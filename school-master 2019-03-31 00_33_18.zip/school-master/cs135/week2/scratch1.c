// Scratch file 9/12/17

#include <stdio.h>
#include <stdbool.h>

int main(void)
{
    bool t = true;
    bool f = false;
    bool t2 = 1;
    bool f2 = 0;

    return 0;
}
