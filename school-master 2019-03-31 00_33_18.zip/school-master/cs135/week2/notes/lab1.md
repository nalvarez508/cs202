# Lab[1] - 9/11/17

Instructor: Sayed - PhD CS student


