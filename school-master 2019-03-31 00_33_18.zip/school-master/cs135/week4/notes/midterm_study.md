### STUDY THIS SHIT

Exam topics
 - General questions
 - Operators, evaluating expressions, operator precedence
 - Basic data types
 - Input/output using `printf` and `scanf`
 - Given a piece of code, write what will be the output/behavior
 - Write small program(s)/code fragments that use `if`/`else`, `switch`, and loops.

Tips
 - Make no assumptions. Read carefully.
 - Do not write more or less than required.
