# Lecture[4][1] Notes
Date: 9/28/17

#### REVIEW: Constants
Numbers that appear in text of program. C allows integer constants to be written
in decimal (base 10), octal, or hexadecimal. Memory often uses hex. Octal and
hex are used because they convert directly to binary. 3 bits (base 8) or four
bits (base 16).

Compiler will interpret a bare number as decimal. If there's a leading 0, will
assume octal. If a leading x (or maybe 0x) will assume hex.

## Arrays
All review. See [ch8.md](../../readings/ch8.md) for the rest.
