/*
 * Scratch file for lecture[1][1]
 */

#include <stdio.h>

int main(void)
{
    
}
