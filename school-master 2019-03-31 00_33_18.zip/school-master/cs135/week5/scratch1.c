// Scratch file

#include <stdio.h>

int main(void)
{
    int a = 5;
    float b = 2.7;

    printf("%5.3d\n", a);
    printf("%5.3f\n", b);

    return 0;

}
