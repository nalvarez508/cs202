// Scratch file

#include <stdio.h>

int main(void)
{

    int i = 1, j = 5;
    i, j = ++i, i + j;
    printf("%d %d\n", i, j);
    return 0;

}
