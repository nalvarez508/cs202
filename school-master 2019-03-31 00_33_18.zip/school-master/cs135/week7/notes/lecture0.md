# Lecture[7][] Notes - MultiDimensional Arrays
Date: 10/17/17

No real notes today. We began discussing Functions at the end of lecture, but
didn't get too deep. The rest of lecture was spent discussing implementation
of the unfinished practice problems below.

#### Program: [Calculate Interest](../interest.c)
Incomplete, but leaving for reference. The idea was to write a program
which would allow the user to input an interest rate (int) and number of years
(int) and the program would calculate interest accrued over that number of
years. I stopped because I ran out of time, but my implementation was also
flawed. The professor's suggestion was to use a 3d array to store the total
dollar amounts (including accrued interest) over time, but I was instead going
to try to do all the calculations on the fly without storing anything. I didn't
think about how I was going to calc the interest, however, so I got stuck.

#### Program: [Dealing a Hand of Cards](../deal.c)
Incomplete, but leaving for reference. Use a multi-dimensional array to simulate
dealing cards from a standard 52-card deck. Use C's pseudo-random number
generator to randomly select cards to deal.
