# Lecture[7][1] Notes - Functions
Date: 10/19/17

#### Program: [Computing Averages](../average.c)
