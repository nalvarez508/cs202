// Linked list in C
// Uses Struct, which we haven't covered yet. I thought it would be good
// pointer practice.

#include <stdio.h>

int main(void)
{


    return 0;
}
