// Scratch file

#include <stdio.h>

int main(void)
{
    int i, j, *p, *q;

    *p = &i;

    return 0;

}
