#include <iostream>

int main() {
    int i = 0;
    while (i++ < 100) {
        std::cout << i << std::endl;
    }
    return 0;
}
