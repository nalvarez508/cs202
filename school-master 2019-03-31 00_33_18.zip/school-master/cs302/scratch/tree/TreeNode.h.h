//
// Created by Matthew Davis on 10/8/18.
//

#ifndef SCHOOL_TREENODE_H_H
#define SCHOOL_TREENODE_H_H

template<class ItemType>
class TreeNode {
private:
    ItemType item;

};

#endif //SCHOOL_TREENODE_H_H
