#include <iostream>
#include <vector>

#include "ArrayBag.h"
#include "LinkedBag.h"

int main() {
    LinkedBag<int> lb;

    return 0;
}