#include <iostream>
#include <memory>

//#include "SL_PriorityQueue.h"
#include "LinkedSortedList.h"

int main() {
//    SL_PriorityQueue<int> slpq;

//    std::unique_ptr<LinkedSortedList<int>> slistPtr = std::make_unique<LinkedSortedList<int>>();
    LinkedSortedList<int> sls;
}