# CS 302 - Lecture 0.0 - Intro
Date: 8/27/18 | [Slides]()

Prev | [Next](./lecture_0_1.md)

Will probably use WebCampus less. Grades posted there, but it looks
like class data is here: https://www.autonomousrobotslab.com/cs302---data-structures.html

Ubuntu 16.4, class will provide virtual box. Must make sure to use
the correct compiler which will be bundled with provided VM.

Should go over Google C++ Style: https://google.github.io/styleguide/cppguide.html


### Syllabus

### Style