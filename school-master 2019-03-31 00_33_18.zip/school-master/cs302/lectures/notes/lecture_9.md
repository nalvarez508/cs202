### Bonus Assignment - Robot Navigation

- Very easy for computer to regognize patterns -- this is a humnan,
that's cancer on an xray
- Difficult to know where it (the computer) is in space

- What is the best way to store the required data? Correct answer has
something to do with how JPEG algo works


### The ADT Sorted List
- Not the same as a sorted linked list
- It's a data structure which constantly maintains a sorted state -- all
inserts and removals ensure the list remains sorted when complete
