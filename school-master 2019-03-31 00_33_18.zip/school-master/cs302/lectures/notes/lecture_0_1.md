# CS 302 - Lecture 0.1 - OO Concepts, Designing ADTs, Classes, Recursion
Date: 8/29/18 | [Slides]()

[Prev](./lecture_0_0.md) | [Next](./lecture_1_0.md)

Virtual Box Password: CS302 (or cs302)

He said something about enabling virtualization in BIOS. Like I fucking
know what that means.

Homework #1 due Monday 9/10

### Object-Oriented Solutions



