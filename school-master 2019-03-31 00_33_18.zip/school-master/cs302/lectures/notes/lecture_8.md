# CS 302 - Lecture 8 - Sorting Algorithms and Efficiency
Date: 9/24/18

[Prev](./lecture_7.md) | [Next](./lecture_9.md)

