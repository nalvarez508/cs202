# CS 302 - Lecture 3 -
Date: 9/5/18

[Prev](./lecture_0_1.md) | [Next](./lecture_4.md)




