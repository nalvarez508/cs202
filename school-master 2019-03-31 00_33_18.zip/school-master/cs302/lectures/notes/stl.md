`std::vector`
- Dynamically sized array
- Automatically re