# Masters in Computer Science
University of Nevada, Reno | 2017 - 2020 (projected)

## Classes
- [CS 135](./cs135) - Erin Keith - Fall 2017
- [CS 202](./cs202) - Christos Papachristos - Spring 2018
- [CS 302](./cs302) - Konstantinos Alexis - Spring 2018
