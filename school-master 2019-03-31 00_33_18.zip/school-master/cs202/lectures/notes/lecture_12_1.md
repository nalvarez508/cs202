# CS 202 - Lecture 12.1 - C++ Templates (part 2)
Date: 4/26/18 | [Slides](../CS202_Lecture23_[Templates_(Pt.2)]_04.24.pdf)

[Prev](./lecture_12_0.md) | [Next](./lecture_13_0.md)

