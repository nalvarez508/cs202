# CS 202 - Lecture 11.1 - C++ Templates (part 3)
Date: 4/19/18 | [Slides](../CS202_Lecture22_[Templates_(Pt.1)]_04.19.pdf)

[Prev](./lecture_11_0.md) | [Next](./lecture_12_0.md)

> Had to leave early, so didn't take any notes. Prof didn't
even get to the above slides, so shouldn't be a problem.