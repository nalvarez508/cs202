# CS 202 - Lecture 5.0 - C++ Classes - Inheritance (part 1)
Date: 2/22/18 | [Slides](../slides/CS202_Lecture10_[C++_Classes-Inheritance_(Pt.1)]_02.22.pdf)

[Prev](./lecture_4_0.md) | [Next](./lecture_5_0.md)

## Operator overloading