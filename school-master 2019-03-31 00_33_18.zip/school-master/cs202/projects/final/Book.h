//
// Created by Matthew Davis on 5/7/18.
//

#ifndef SCHOOL_BOOK_H
#define SCHOOL_BOOK_H


class Book {
public:
    Book();
//    Book(const char * name, const Cover & cover, const Client & client, const size_t serial);

};


#endif //SCHOOL_BOOK_H
