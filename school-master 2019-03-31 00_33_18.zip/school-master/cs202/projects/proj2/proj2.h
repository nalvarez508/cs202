//
// Created by Matthew Davis on 2/1/18.
//

#ifndef CS202_CAR_H
#define CS202_CAR_H

struct Car {
    int year;
    char make[10];
    char model[10];
    float price;
    bool available;
};

#endif //CS202_CAR_H
